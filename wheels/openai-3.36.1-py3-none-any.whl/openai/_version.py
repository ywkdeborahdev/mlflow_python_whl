__title__ = "openai"
__version__ = "3.36.1"  # x-release-please-version
